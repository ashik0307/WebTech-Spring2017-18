<?php
$dom = simplexml_load_file("student.xml");

foreach($dom->student as $s)
{
	echo "<h3>$s->name </h3>";
	echo "<h4> $s->id </h4>";
	echo "<h4> $s->cgpa </h4>"; 
	echo "<h2>courses:</h2>"."<br>";
	
	foreach($s->courses->course as $c){
		echo "<li>" .$c->courseName,"</li>";
		echo "<li>" .$c->section,"</li>";
		echo "<li>" .$c->grade,"</li>";
		
		
	}
	
}

?>