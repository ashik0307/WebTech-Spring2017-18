#include <iostream>

using namespace std;

struct studentstruct
{
    string studentname;
    int studentid;
    float cgpa;
    int quize[3]={};

};
void setallstudentinfo(struct playerstudent student[],int size)
{
   student[0].studentname="aslam";
   student[0].studentid="17";
   student[0].cgpa="3.88";
   student[0].quize={18 20 20};

   student[1].studentname="atif";
   student[1].studentid="18"
   student[1].cgpaq="3.89"
   student[1].quizee={20 20 19};

   student[2].studentname="noor";
   student[2].studentid="19"
   student[2].cgpaq="3.89"
   student[2].quizee={20 20 19};
}
int main()
{
    for(i=0;i<3;i++)
    {
        cin>>student[i].studentname ;
        cout<<studentname<<endl;
        cin>>student[i].studentid;
        cout<<studentid<<endl;
        cin>>student[i].cgpa;
        cout<<cgpa<<endl;

    }
}
