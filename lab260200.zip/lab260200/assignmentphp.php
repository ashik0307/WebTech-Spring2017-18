<?php
$dom = simplexml_load_file("assignment001.xml");

foreach($dom->student as $s)
{
	echo "<h2> $s->studentname - </h2>";
	echo "<h2> $s->studentid - </h2>";  
	echo "<h2> $s->CGPA: </h2>";
	echo "<h3>courses:</h3>";
	
	foreach($s->courses->course as $c){
		echo $s->coursename."|".$s->section."|".$s->grade;
		
	}
	
}

?>