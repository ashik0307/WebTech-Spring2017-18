<!DOCTYPE html>
</html>
  <head>
  <title> home </title>
  </head> 
    <body>
	<form>
	<h1> HOME </h1>
	<hr/>
	<input type="reset" value= "logout"/> <br/>
	Hello <?php 
	echo $_post["name"]; ?> <br/>
	<hr/>
	<a href= "userinfo.php" target= "_blank"> User info </a>
	<a href= "userloginfo.php" target="_blank"> User login Info </a>
	</form>
 	</body>
</html>	