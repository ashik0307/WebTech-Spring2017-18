<!DOCTYPE html>
</html>
  <head>
  <title> userinfo </title>
  </head> 
    <body>
	<form>
	<h1 align= "USER INFO"> </h1>
	<hr/>
	<input type="reset" value= "logout"/>
	<a href= "home.php" target= "_blank"> Home </a> <br/> 
	
	</form>
 	</body>
</html>	