<!DOCTYPE html>
</html>
  <head>
  <title> index </title>
  </head>

    <body>
	 <form action="home.php" method= "post">
      <h1> Login </h1> <br>
	  User:<input type= "text" name="user"/> <br>
	  Password:<input type= "password" name="pass"/> <br> 
	  <input type = "submit" value="Submit"/>
	  </form>
	</body>  
</html>      	  